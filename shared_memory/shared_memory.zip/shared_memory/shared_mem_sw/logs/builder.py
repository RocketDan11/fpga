# 2024-10-09T12:58:03.855719500
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/RSass/Research/shared_memory/shared_mem_sw")

proj = client.create_sys_project(name="system_project", platform="C:\Users\RSass\Research\shared_memory\shared_mem_hw\ic20_top_wrapper.xsa", template="empty_accelerated_application")

platform = client.get_component(name="platform_mb")
status = platform.build()

comp = client.get_component(name="main_mb")
comp.build()

platform = client.get_component(name="platform_ps")
status = platform.build()

comp = client.get_component(name="main_ps")
comp.build()

platform = client.get_component(name="platform_mb")
status = platform.build()

comp = client.get_component(name="main_mb")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

platform = client.get_component(name="platform_ps")
status = platform.build()

comp = client.get_component(name="main_ps")
comp.build()

status = platform.build()

comp.build()

vitis.dispose()

