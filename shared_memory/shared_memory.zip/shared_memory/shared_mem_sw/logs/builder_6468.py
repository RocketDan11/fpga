# 2024-10-09T12:36:21.249888
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/RSass/Research/shared_memory/shared_mem_sw")

platform = client.create_platform_component(name = "platform_mb",hw_design = "C:/Users/RSass/Research/shared_memory/shared_mem_hw/ic20_top_wrapper.xsa",os = "standalone",cpu = "microblaze",domain_name = "standalone_microblaze")

platform = client.create_platform_component(name = "platform_ps",hw_design = "C:/Users/RSass/Research/shared_memory/shared_mem_hw/ic20_top_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0",domain_name = "standalone_ps7_cortexa9_0")

comp = client.create_app_component(name="main_mb",platform = "C:/Users/RSass/Research/shared_memory/shared_mem_sw/platform_mb/export/platform_mb/platform_mb.xpfm",domain = "standalone_microblaze",template = "hello_world")

comp = client.create_app_component(name="main_ps",platform = "C:/Users/RSass/Research/shared_memory/shared_mem_sw/platform_ps/export/platform_ps/platform_ps.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

platform = client.get_component(name="platform_mb")
status = platform.build()

comp = client.get_component(name="main_mb")
comp.build()

status = platform.build()

platform = client.get_component(name="platform_ps")
status = platform.build()

vitis.dispose()

